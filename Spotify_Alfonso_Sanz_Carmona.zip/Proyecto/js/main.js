const cancionesDiv = document.querySelector(".canciones");
const botonPlay = document.querySelector(".boton-verde");
const footerPlayIcon = document.querySelector(".icono-play");
const audioElement = new Audio();
let isPlaying = false;
let cancionActual = null;
let canciones = []; // Guarda todas las canciones cargadas
let mostrarFavoritos = false; // Variable para manejar el filtro

// Elementos de la barra de progreso
const barraProgreso = document.querySelector(".barra-progreso");
const progreso = document.querySelector(".progreso");
const tiempoInicial = document.querySelector(".tiempo-inicial");
const tiempoFinal = document.querySelector(".tiempo-final");

// Campo de búsqueda
const inputBusqueda = document.querySelector(".input-busqueda");

// Contenedor para la imagen
const contenedorImagenes = document.querySelector(".contenedorImagenes");

// Elementos de filtro
const opcionTodos = document.getElementById("todos");
const opcionFavoritos = document.getElementById("favoritos");

//Formulario
const formulario = document.getElementById("formulario");
const botonAñadir = document.getElementById("añadir-cancion");
const botonCerrar = document.getElementById("cerrar-formulario");

// Elementos para mostrar la información de la canción
const tituloCancion = document.querySelector(".cancion-actual");
const nombreArtista = document.querySelector(".artista");

// Iconos de control
const controles = document.querySelectorAll(".icono-control");

// Elementos para el volumen
const iconoVolumen = document.querySelector(".icono-volumen");
const sliderVolumen = document.querySelector(".slider-volumen");
let volumenActual = 0.5; 
audioElement.volume = volumenActual; 
const progresoVolumen = document.querySelector(".progreso-volumen");

// Aquí me aseguro que los elementos existan
if (opcionTodos) {
  opcionTodos.addEventListener("click", () => {
    mostrarFavoritos = false; 
    cargarCanciones(); 
  });
}

if (opcionFavoritos) {
  opcionFavoritos.addEventListener("click", () => {
    mostrarFavoritos = true;  
    cargarCanciones(); 
  });
}

//Get
// Función para cargar las canciones desde el servidor
async function cargarCanciones(busqueda = "") {
    try {
      const response = await fetch("http://informatica.iesalbarregas.com:7008/songs/");
      if (!response.ok) throw new Error("Error al cargar canciones");
  
      canciones = await response.json();
  
      const favoritosGuardados = JSON.parse(localStorage.getItem("favoritos")) || [];
  
      cancionesDiv.innerHTML = ""; 
  
      // Filtrar canciones por búsqueda (si hay texto)
      const cancionesFiltradas = canciones.filter(cancion => 
        cancion.title.toLowerCase().includes(busqueda.toLowerCase()) ||
        cancion.artist.toLowerCase().includes(busqueda.toLowerCase())
      );
  
      // Procesar canciones filtradas
      for (const cancion of cancionesFiltradas) {
        const duracion = await obtenerDuracion(cancion.filepath); 
        const cancionDiv = document.createElement("div");
        cancionDiv.className = "cancion-item";
        cancionDiv.innerHTML = `
          <div>${cancion.title}</div>
          <div>${cancion.artist}</div>
          <div>${duracion}</div>
          <div>
            <span class="corazon" data-id="${cancion.id}">&#x2661;</span>
          </div>`;
  
        const corazon = cancionDiv.querySelector(".corazon");
        if (favoritosGuardados.includes(cancion.id)) {
          corazon.innerHTML = "&#x2665;"; 
          corazon.style.color = "green"; 
          cancion.favorito = true; 
        } else {
          cancion.favorito = false; 
        }
  
        corazon.addEventListener("click", () => marcarFavorito(cancion, corazon));
  
        if (!mostrarFavoritos || cancion.favorito) {
          cancionDiv.addEventListener("click", () => seleccionarCancion(cancion));
          cancionesDiv.appendChild(cancionDiv);
        }
      }
    } catch (error) {
      console.error("Error al cargar canciones:", error);
    }
  }
  

// Función para obtener la duración de un archivo de audio
function obtenerDuracion(filepath) {
  return new Promise((resolve) => {
    const audioTemp = new Audio(filepath);
    audioTemp.addEventListener("loadedmetadata", () => {
      const minutos = Math.floor(audioTemp.duration / 60);
      const segundos = Math.floor(audioTemp.duration % 60);
      resolve(`${minutos}:${segundos < 10 ? "0" : ""}${segundos}`);
    });
    audioTemp.addEventListener("error", () => resolve("Desconocido"));
  });
}

// Función para seleccionar y reproducir una canción
function seleccionarCancion(cancion) {
    if (cancionActual?.filepath === cancion.filepath && isPlaying) {
      alternarPlayPause(); 
    } else {
      cancionActual = cancion;
      // Cargamos el nuevo audio antes de reproducir
      audioElement.src = cancion.filepath;
      audioElement.load();
      audioElement.play().catch((error) => {
        console.error("Error al intentar reproducir el audio:", error);
      });
      isPlaying = true;
      actualizarEstadoBotones();
  
      // Actualizar la información de la canción y el artista
      actualizarInfoCancion(cancion);
    }
  
    // Si la canción seleccionada es la primera, puedes mostrar la imagen como lo haces ahora
    if (cancion.title === canciones[0].title) {
      mostrarImagen(); 
    }
  }

  // Función para actualizar la información de la canción y el artista
function actualizarInfoCancion(cancion) {
    tituloCancion.textContent = cancion.title;  // Actualiza el título de la canción
    nombreArtista.textContent = cancion.artist; // Actualiza el nombre del artista
  }

// Función mostrar la imagen
function mostrarImagen() {
  contenedorImagenes.innerHTML = "";

  const imagen = document.createElement("img");
  imagen.src = "/img/MariahCareynavidad.jpg"; 
  imagen.alt = "Mariah Carey Navidad";

  imagen.className = "imagenArtista";

  contenedorImagenes.style.display = "flex";
  contenedorImagenes.style.alignItems = "center"; 

  contenedorImagenes.appendChild(imagen);
}

// Función para marcar como favorito
function marcarFavorito(cancion, corazon) {
  cancion.favorito = !cancion.favorito; 
  if (cancion.favorito) {
    corazon.innerHTML = "&#x2665;"; 
    corazon.style.color = "green"; 
  } else {
    corazon.innerHTML = "&#x2661;";
    corazon.style.color = "green"; 
  }

  actualizarFavoritos();
}

// Función para abrir el formulario
botonAñadir.addEventListener("click", () => {
  formulario.style.display = "block"; 
  setTimeout(() => { 
    formulario.classList.add("aparecer"); 
  }, 10); 
});

// Función para cerrar el formulario
botonCerrar.addEventListener("click", () => {
  formulario.style.display = "none"; 
  formulario.classList.remove("aparecer"); 
});


// Actualiza los favoritos en el localStorage
function actualizarFavoritos() {
  const favoritos = canciones.filter(cancion => cancion.favorito).map(cancion => cancion.id);
  localStorage.setItem("favoritos", JSON.stringify(favoritos));
}

// Alternar entre reproducir y pausa
function alternarPlayPause() {
  if (isPlaying) {
    audioElement.pause();
  } else {
    if (!cancionActual) {
      seleccionarCancion(canciones[0]); 
    } else {
      audioElement.play().catch((error) => {
        console.error("Error al intentar reproducir el audio:", error);
      });
    }
  }
  isPlaying = !isPlaying;
  actualizarEstadoBotones();
}

// Botones play/pause
function actualizarEstadoBotones() {
  if (isPlaying) {
    botonPlay.textContent = "Pause";
    footerPlayIcon.src = "/img/pause-circle-regular-24.png";
  } else {
    botonPlay.textContent = "Play";
    footerPlayIcon.src = "/img/play-circle-regular-24.png";
  }
}

// Actualizar barra de progreso
function actualizarBarraProgreso() {
  if (audioElement.duration) {
    const progresoPorcentaje =
      (audioElement.currentTime / audioElement.duration) * 100;
    progreso.style.width = `${progresoPorcentaje}%`;

    const minutosInicial = Math.floor(audioElement.currentTime / 60);
    const segundosInicial = Math.floor(audioElement.currentTime % 60);
    tiempoInicial.textContent = `${minutosInicial}:${segundosInicial < 10 ? "0" : ""}${segundosInicial}`;

    const minutosFinal = Math.floor(audioElement.duration / 60);
    const segundosFinal = Math.floor(audioElement.duration % 60);
    tiempoFinal.textContent = `${minutosFinal}:${segundosFinal < 10 ? "0" : ""}${segundosFinal}`;
  }
}

// Manejar la barra de progreso
barraProgreso.addEventListener("click", (e) => {
  const anchoTotal = barraProgreso.offsetWidth;
  const posicionClick = e.offsetX;
  const nuevoTiempo = (posicionClick / anchoTotal) * audioElement.duration;
  audioElement.currentTime = nuevoTiempo;
});

setInterval(actualizarBarraProgreso, 1000);

botonPlay.addEventListener("click", alternarPlayPause);
footerPlayIcon.addEventListener("click", alternarPlayPause);

audioElement.addEventListener("ended", () => {
  isPlaying = false;
  actualizarEstadoBotones();
});

// Funciones de volumen
sliderVolumen.addEventListener("input", (e) => {
  const nuevoVolumen = e.target.value / 100;
  audioElement.volume = nuevoVolumen;
  volumenActual = nuevoVolumen;
  actualizarIconoVolumen();
});

iconoVolumen.addEventListener("click", () => {
  if (audioElement.volume > 0) {
    volumenActual = audioElement.volume;
    audioElement.volume = 0;
    sliderVolumen.value = 0;
  } else {
    audioElement.volume = volumenActual;
    sliderVolumen.value = volumenActual * 100;
  }
  actualizarIconoVolumen();
});

function actualizarIconoVolumen() {
  if (audioElement.volume === 0) {
    iconoVolumen.src = "/img/volume-mute-solid-24.png";
  } else if (audioElement.volume >= 0.7) {
    iconoVolumen.src = "/img/volume-full-solid-24.png";
  } else {
    iconoVolumen.src = "/img/volume-low-solid-24.png";
  }
}

// Agregamos el evento de búsqueda
inputBusqueda.addEventListener("input", () => {
    const busqueda = inputBusqueda.value.trim(); 
    cargarCanciones(busqueda); 
  });

// Actualizar la barra de progreso del volumen
sliderVolumen.addEventListener("input", (e) => {
    const nuevoVolumen = e.target.value / 100;
    audioElement.volume = nuevoVolumen;
    volumenActual = nuevoVolumen;
    actualizarIconoVolumen();
    actualizarBarraVolumen(); // Actualizar la barra de progreso
  });
  
  // Función para actualizar la barra de progreso del volumen
  function actualizarBarraVolumen() {
    const porcentajeVolumen = audioElement.volume * 100;
    progresoVolumen.style.width = `${porcentajeVolumen}%`;
  }
  

  // Inicializar la barra de progreso del volumen al cargar
  actualizarBarraVolumen();

cargarCanciones();
